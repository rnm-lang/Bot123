// routes/oauth.js

const express = require('express');
const axios = require('axios');
const router = express.Router();
require('dotenv').config();

const {
  CLIENT_ID,
  CLIENT_SECRET,
  REDIRECT_URI,
  PRIVATE_GUILD_ID,
  DISCORD_TOKEN
} = process.env;

// Step 1: Redirect user to Discord login
router.get('/login', (req, res) => {
  const oauthURL = `https://discord.com/api/oauth2/authorize` +
    `?client_id=${CLIENT_ID}` +
    `&redirect_uri=${encodeURIComponent(REDIRECT_URI)}` +
    `&response_type=code` +
    `&scope=identify%20guilds.join%20email`;

  res.redirect(oauthURL);
});

// Step 2: Handle Discord OAuth2 callback
router.get('/callback', async (req, res) => {
  const code = req.query.code;
  if (!code) return res.status(400).send('No code provided');

  try {
    // Step 3: Exchange code for access token
    const tokenResponse = await axios.post('https://discord.com/api/oauth2/token',
      new URLSearchParams({
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: REDIRECT_URI,
        scope: 'identify guilds.join email',
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    const accessToken = tokenResponse.data.access_token;

    // Step 4: Get user details
    const userResponse = await axios.get('https://discord.com/api/users/@me', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    const user = userResponse.data;

    // Optional: log user info or verify manually
    console.log(`User: ${user.username}#${user.discriminator} (${user.id})`);

    // Step 5: Add user to private server
    await axios.put(
      `https://discord.com/api/guilds/${PRIVATE_GUILD_ID}/members/${user.id}`,
      {
        access_token: accessToken,
      },
      {
        headers: {
          Authorization: `Bot ${DISCORD_TOKEN}`,
          'Content-Type': 'application/json',
        },
      }
    );

    // Step 6: Success response
    res.send(`
      <h1>✅ You have been verified and added to the server!</h1>
      <p>Welcome, ${user.username}!</p>
    `);

  } catch (err) {
    console.error('OAuth Error:', err.response?.data || err.message);
    res.status(500).send('❌ Something went wrong during OAuth2 verification.');
  }
});

module.exports = router;
