const mongoose = require('mongoose');

const capperSchema = new mongoose.Schema({
  userId: String,
  username: String,
  channelId: String,           // <--- Add this line
  addedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.Capper || mongoose.model('Capper', capperSchema);
