const mongoose = require('mongoose');

const betslipSchema = new mongoose.Schema({
  capperId: { type: String, required: true },
  messageId: { type: String, required: true },
  platform: { type: String, required: true },
  sport: { type: String, required: true },
  betType: { type: String, required: true },
  title: { type: String, required: true },
  units: { type: Number, required: true },
  americanOdds: { type: Number, required: true },
  decimalOdds: { type: Number, required: true },
  betslipLink: { type: String, required: true },
  description: { type: String },
  imageUrl: { type: String },
  result: { type: String, enum: ['win', 'push', 'loss', null], default: null },
  createdAt: { type: Date, default: Date.now },
});

// Avoid OverwriteModelError in dev environment
module.exports = mongoose.models.Betslip || mongoose.model('Betslip', betslipSchema);
