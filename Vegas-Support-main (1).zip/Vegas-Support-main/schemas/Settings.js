const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  logsChannelId: { type: String },
});

module.exports = mongoose.model('Settings', settingsSchema);
