// googleSheetsHelper.js
const { google } = require('googleapis');
const credentials = require('../../SlipBuddy/google-credentials.json');

const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];
const auth = new google.auth.GoogleAuth({
  credentials,
  scopes: SCOPES,
});
const sheets = google.sheets({ version: 'v4', auth });

async function appendToSheet(sheetName, rows) {
  const spreadsheetId = '14hdRKvrq_yqUA3zyxvBTtDUil5GDR36A9SABKKbRZYQ'; // Replace with your spreadsheet ID
  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range: `${sheetName}!A1`,
    valueInputOption: 'USER_ENTERED',
    resource: {
      values: rows,
    },
  });
}

module.exports = { appendToSheet };
