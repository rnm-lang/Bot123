const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Capper = require('../../schemas/Capper');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removecapper')
    .setDescription('Remove a user from cappers')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to remove as capper')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const existing = await Capper.findOne({ userId: user.id });

    if (!existing) {
      return interaction.reply({ content: '⚠️ That user is not a capper.'});
    }

    await Capper.deleteOne({ userId: user.id });

    // Find and delete their channel
    const category = interaction.guild.channels.cache.find(
      c => c.name.toLowerCase() === 'grade your bets' && c.type === 4
    );
    const userChannel = interaction.guild.channels.cache.find(
      c => c.parentId === category?.id && c.name === user.username.toLowerCase()
    );

    if (userChannel) {
      await userChannel.delete();
    }

    return interaction.reply({ content: `✅ ${user.username} has been removed as a capper and their channel deleted.`});
  }
};