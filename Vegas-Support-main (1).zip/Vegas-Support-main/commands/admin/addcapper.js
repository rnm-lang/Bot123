const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType } = require('discord.js');
const Capper = require('../../schemas/Capper');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addcapper')
    .setDescription('Add a user as an authorized capper')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to add as capper')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    try {
      const user = interaction.options.getUser('user');
      const existing = await Capper.findOne({ userId: user.id });

      if (existing) {
        return interaction.reply({ content: '⚠️ That user is already a capper.', ephemeral: true });
      }

      // Find category named "Grade Your Bets"
      const category = interaction.guild.channels.cache.find(
        c => c.name.toLowerCase() === 'grade your bets' && c.type === ChannelType.GuildCategory
      );

      // Create private channel for capper
      const channel = await interaction.guild.channels.create({
        name: user.username.toLowerCase(),
        type: ChannelType.GuildText,
        parent: category?.id ?? null,
        permissionOverwrites: [
          {
            id: interaction.guild.id, // @everyone
            deny: ['ViewChannel'],
          },
          {
            id: user.id,
            allow: ['ViewChannel', 'SendMessages', 'AttachFiles'],
          },
          {
            id: interaction.user.id, // Admin who ran command
            allow: ['ViewChannel'],
          },
        ],
      });

      // Add to DB with channelId saved
      await Capper.create({ userId: user.id, username: user.username, channelId: channel.id });

      // Build embed message
      const embed = new EmbedBuilder()
        .setColor('#7B3FBF')
        .setTitle('Capper Added')
        .setDescription(`✅ **${user.tag}** has been added as a capper and channel has been created.`)
        .setTimestamp()
        .setFooter({ text: 'SlipBuddy Bot' });

      return interaction.reply({ embeds: [embed]});

    } catch (error) {
      console.error('Error in addcapper command:', error);
      return interaction.reply({ content: '❌ There was an error adding the capper. Please try again later.'});
    }
  }
};