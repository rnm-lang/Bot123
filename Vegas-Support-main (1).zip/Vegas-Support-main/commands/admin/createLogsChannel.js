// commands/admin/createLogsChannel.js
const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const Settings = require('../../schemas/Settings'); // new schema for saving the logs channel

module.exports = {
  data: new SlashCommandBuilder()
    .setName('create-logs-channel')
    .setDescription('Create a private channel to log all betslips')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const guild = interaction.guild;

    const channel = await guild.channels.create({
      name: '💰・plays',
      type: ChannelType.GuildText,
      topic: 'This channel stores all betslip posts for moderation/auditing.',
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: ['ViewChannel'],
        },
        {
          id: interaction.client.user.id, // bot can send
          allow: ['ViewChannel', 'SendMessages', 'EmbedLinks'],
        },
        {
          id: interaction.user.id, // creator can see it
          allow: ['ViewChannel', 'SendMessages'],
        },
      ],
    });

    // Save it in DB
    await Settings.findOneAndUpdate(
      { guildId: guild.id },
      { logsChannelId: channel.id },
      { upsert: true }
    );

    await interaction.reply({
      embeds: [
        {
          description: `✅ Logs channel created: ${channel}`,
          color: 0x7B3FBF,
        },
      ],
    });
  }
};