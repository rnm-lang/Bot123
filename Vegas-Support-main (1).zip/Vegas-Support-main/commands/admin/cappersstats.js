const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Betslip = require('../../schemas/Betslip');
const Capper = require('../../schemas/Capper');
const moment = require('moment');

// Date references
const today = moment().startOf('day');
const yesterday = moment().subtract(1, 'day').startOf('day');
const sevenDaysAgo = moment().subtract(7, 'days').startOf('day');
const monthStart = moment().startOf('month');
const yearStart = moment().startOf('year');

function calculateStats(bets) {
  let profit = 0, wins = 0, losses = 0, pushes = 0;

  for (const bet of bets) {
    if (bet.result === 'win' && bet.decimalOdds && bet.units) {
      profit += bet.units * (bet.decimalOdds - 1);
      wins++;
    } else if (bet.result === 'loss' && bet.units) {
      profit -= bet.units;
      losses++;
    } else if (bet.result === 'push') {
      pushes++;
    }
  }

  return { profit: +profit.toFixed(2), wins, losses, pushes, total: bets.length };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cappersstats')
    .setDescription('Show stats summary for all cappers or a specific capper')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption(option =>
      option.setName('target')
        .setDescription('Select a capper user for stats')
        .setRequired(false)
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const targetUser = interaction.options.getUser('target');

    if (targetUser) {
      const capper = await Capper.findOne({ userId: targetUser.id });
      if (!capper) {
        return interaction.editReply(`No capper data found for ${targetUser.tag}.`);
      }

      const bets = await Betslip.find({ capperId: targetUser.id }) || [];
      if (!bets.length) {
        return interaction.editReply(`No bets found for ${targetUser.tag}.`);
      }

      const statsYesterday = calculateStats(bets.filter(bet => moment(bet.createdAt).isSame(yesterday, 'day')));
      const stats7Days = calculateStats(bets.filter(bet => moment(bet.createdAt).isSameOrAfter(sevenDaysAgo)));
      const statsThisMonth = calculateStats(bets.filter(bet => moment(bet.createdAt).isSameOrAfter(monthStart)));
      const statsYTD = calculateStats(bets.filter(bet => moment(bet.createdAt).isSameOrAfter(yearStart)));

      const { profit, wins, losses, pushes } = calculateStats(bets);

      const maxBets = 15;
      const betLines = bets.slice(0, maxBets).map(bet => {
        const title = bet.title.length > 15 ? bet.title.slice(0, 12) + '...' : bet.title.padEnd(15);
        const sport = bet.sport.padEnd(10);
        const odds = (bet.americanOdds >= 0 ? `+${bet.americanOdds}` : `${bet.americanOdds}`).padStart(6);
        const units = bet.units.toFixed(2).padStart(6);
        const result = (bet.result || 'PENDING').toUpperCase().padEnd(7);
        return `${title}  ${sport}  ${odds}  ${units}  ${result}`;
      }).join('\n');

      const betsTable = `\`\`\`\nTitle           Sport      Odds   Units  Result\n------------------------------------------------\n${betLines}${bets.length > maxBets ? `\n...and ${bets.length - maxBets} more bets` : ''}\n\`\`\``;

      const embed = new EmbedBuilder()
        .setTitle(`${capper.username || targetUser.tag} - Bets Overview`)
        .setColor('#9b59b6')
        .addFields(
          { name: 'Summary', value: `**Wins:** ${wins}\n**Losses:** ${losses}\n**Pushes:** ${pushes}\n**Profit:** ${profit} units\n**Total Bets:** ${bets.length}`, inline: true },
          { name: 'Overall', value: `**Yesterday:** ${statsYesterday.profit} units\n**Last 7 Days:** ${stats7Days.profit} units\n**This Month:** ${statsThisMonth.profit} units\n**YTD:** ${statsYTD.profit} units\n**All Time:** ${profit} units`, inline: true }
        )
        .setImage(`https://media.discordapp.net/attachments/1113081965525094452/1218951663562526720/Comp_1.gif?ex=683a7e73&is=68392cf3&hm=066c7e2f1bbd7c98b59d9c8ba346507994f4edb0cdf0fa254bdcde2dd98a44fc&=&width=675&height=14`)
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
      return interaction.followUp({ content: betsTable });
    }

    // Overall Server Stats
    const cappers = await Capper.find({}) || [];
    if (!cappers.length) return interaction.editReply('No cappers found in the database.');

    const allBets = await Betslip.find({}) || [];
    const globalStats = calculateStats(allBets);

    const globalEmbed = new EmbedBuilder()
      .setTitle('Server Overall Stats')
      .setColor('#2ecc71')
      .setDescription(`Total Bets: ${globalStats.total}\nWins: ${globalStats.wins}\nLosses: ${globalStats.losses}\nPushes: ${globalStats.pushes}\nProfit: ${globalStats.profit} units`)
      .setTimestamp();

    const capperLines = cappers.map(capper => {
      const bets = allBets.filter(bet => bet.capperId === capper.userId);
      if (!bets.length) return null;
      const stats = calculateStats(bets);
      const name = (capper.username || capper.userId).padEnd(18);
      const profit = stats.profit.toFixed(2).padStart(8);
      const wins = stats.wins.toString().padStart(4);
      const losses = stats.losses.toString().padStart(6);
      const pushes = stats.pushes.toString().padStart(6);
      const total = stats.total.toString().padStart(6);
      return `${name}  ${profit}  ${wins}  ${losses}  ${pushes}  ${total}`;
    }).filter(Boolean).join('\n');

    const cappersTable = `\`\`\`\nCapper              | Profit  | Wins | Losses | Pushes | Total\n-------------------------------------------------------------\n${capperLines}\n\`\`\``;

    await interaction.editReply({ embeds: [globalEmbed] });
    await interaction.followUp(cappersTable);

    // All Betslips Table
    const betLines = allBets.map(bet => {
      const capper = cappers.find(c => c.userId === bet.capperId);
      const capperName = capper?.username || bet.capperId;
      const name = capperName.length > 15 ? capperName.slice(0, 12) + '...' : capperName.padEnd(15);
      const title = bet.title.length > 15 ? bet.title.slice(0, 12) + '...' : bet.title.padEnd(15);
      const sport = bet.sport.padEnd(10);
      const odds = (bet.americanOdds >= 0 ? `+${bet.americanOdds}` : `${bet.americanOdds}`).padStart(6);
      const units = bet.units.toFixed(2).padStart(6);
      const result = (bet.result || 'PENDING').toUpperCase().padEnd(7);
      return `${name} | ${title} | ${sport} | ${odds} | ${units} | ${result}`;
    });

    const allBetsTable = `\`\`\`\nCapper           | Title           | Sport      | Odds   | Units  | Result\n----------------------------------------------------------------------------\n${betLines.join('\n')}\n\`\`\``;

    await interaction.followUp(allBetsTable);
  },
};
