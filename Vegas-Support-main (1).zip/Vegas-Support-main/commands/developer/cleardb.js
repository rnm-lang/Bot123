const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const Capper = require('../../schemas/Capper');
const Betslip = require('../../schemas/Betslip');

const MASTER_PASSWORD = 'Ryan'; // Change this to your secret

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cleardb')
    .setDescription('⚠️ DANGEROUS: Clear the entire MongoDB database (admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('cleardbModal')
      .setTitle('🔐 Confirm Clear Database')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('password')
            .setLabel('Enter the master password')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        )
      );

    await interaction.showModal(modal);

    const modalSubmit = await interaction.awaitModalSubmit({
      filter: i => i.user.id === interaction.user.id,
      time: 30000
    }).catch(() => null);

    if (!modalSubmit) {
      return interaction.followUp({ content: '⏰ Timed out. Database not cleared.', ephemeral: true });
    }

    const passwordInput = modalSubmit.fields.getTextInputValue('password');

    if (passwordInput !== MASTER_PASSWORD) {
      return modalSubmit.reply({ content: '❌ Incorrect password. You are not allowed to clear the database.', ephemeral: true });
    }

    const confirmRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('confirmClearDB')
        .setLabel('🧨 Confirm Wipe')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('cancelClearDB')
        .setLabel('❌ Cancel')
        .setStyle(ButtonStyle.Secondary)
    );

    const confirmEmbed = new EmbedBuilder()
      .setTitle('⚠️ Final Warning')
      .setDescription('This will **DELETE ALL DATA** in the database permanently.\nAre you absolutely sure?')
      .setColor('#ff0000')
      .setTimestamp();

    await modalSubmit.reply({ embeds: [confirmEmbed], components: [confirmRow], ephemeral: true });

    const collector = modalSubmit.channel.createMessageComponentCollector({
      filter: i => i.user.id === interaction.user.id,
      time: 15000,
      max: 1
    });

    collector.on('collect', async button => {
      if (button.customId === 'cancelClearDB') {
        return button.update({ content: '❌ Database wipe cancelled.', embeds: [], components: [] });
      }

      if (button.customId === 'confirmClearDB') {
        await Capper.deleteMany({});
        await Betslip.deleteMany({});

        await button.update({
          embeds: [new EmbedBuilder()
            .setTitle('✅ Database Cleared')
            .setDescription('All Capper and Betslip data has been wiped.')
            .setColor('#8e44ad')
            .setTimestamp()],
          components: []
        });
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        modalSubmit.editReply({ content: '⏰ No action taken. Database safe.', embeds: [], components: [] });
      }
    });
  }
};
