const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const os = require('os');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('🏓 Check the bot’s latency and stats!'),

  async execute(interaction) {
    const sent = await interaction.reply({ content: '🏓 Pinging...', fetchReply: true });
    const latency = sent.createdTimestamp - interaction.createdTimestamp;
    const apiLatency = Math.round(interaction.client.ws.ping);

    // Calculate uptime
    const totalSeconds = Math.floor(interaction.client.uptime / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const uptime = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    // Node.js version
    const nodeVersion = process.version;

    // MongoDB connection status (assuming mongoose)
    let mongoStatus = '❌ Disconnected';
    try {
      const mongoose = require('mongoose');
      const states = ['Disconnected', 'Connected', 'Connecting', 'Disconnecting'];
      mongoStatus = mongoose.connection.readyState !== undefined ? 
                    `✅ ${states[mongoose.connection.readyState]}` : mongoStatus;
    } catch {
      mongoStatus = '❓ Unknown (mongoose not found)';
    }

    const embed = new EmbedBuilder()
      .setTitle('📡 Bot Latency & Stats')
      .setColor('#8e44ad')
      .setDescription('Here’s the bot status ⚡')
      .addFields(
        { name: '🌐 API Latency', value: `\`${apiLatency}ms\``, inline: true },
        { name: '🛠️ Node.js Version', value: nodeVersion, inline: true },
        { name: '🗄️ MongoDB Connection', value: mongoStatus, inline: true },
        { name: '⏳ Uptime', value: uptime, inline: true },
      )
      .setFooter({ text: 'Pinged with love ❤️', iconURL: interaction.client.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.editReply({ content: ' ', embeds: [embed] });
  },
};
