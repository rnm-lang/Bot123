const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('send')
    .setDescription('Send a message to a specific channel.')
    .addStringOption(option =>
      option.setName('content')
        .setDescription('The message content')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('message_id')
        .setDescription('The message ID to reply to (optional)')
        .setRequired(false))
    .addBooleanOption(option =>
      option.setName('embed')
        .setDescription('Send as an embed (true/false)')
        .setRequired(false)),
  
  async execute(interaction) {
    const allowedChannelId = '1375930052889280643'; // Command only here
    const targetChannelId = '1377832386343211109';  // Messages sent here
    const adminRoleId = '1375927086803587153';            // Replace with your Admin role ID

    // Restrict channel
    if (interaction.channel.id !== allowedChannelId) {
      return interaction.reply({ content: `❌ This command can only be used in <#${allowedChannelId}>.`, ephemeral: true });
    }

    // Restrict role
    if (!interaction.member.roles.cache.has(adminRoleId)) {
      return interaction.reply({ content: `❌ You don't have permission to use this command.`, ephemeral: true });
    }

    const content = interaction.options.getString('content');
    const messageId = interaction.options.getString('message_id');
    const isEmbed = interaction.options.getBoolean('embed') || false;

    const targetChannel = await interaction.client.channels.fetch(targetChannelId);
    if (!targetChannel) {
      return interaction.reply({ content: `❌ Could not find the target channel.`, ephemeral: true });
    }

    try {
      let sentMessage;
      if (messageId) {
        const targetMessage = await targetChannel.messages.fetch(messageId).catch(() => null);
        if (!targetMessage) {
          return interaction.reply({ content: `❌ Could not find message with ID ${messageId} in <#${targetChannelId}>.`, ephemeral: true });
        }
        if (isEmbed) {
          const embed = new EmbedBuilder().setDescription(content).setColor('#7B3FBF');
          sentMessage = await targetMessage.reply({ embeds: [embed] });
        } else {
          sentMessage = await targetMessage.reply({ content });
        }
      } else {
        if (isEmbed) {
          const embed = new EmbedBuilder().setDescription(content).setColor('#7B3FBF');
          sentMessage = await targetChannel.send({ embeds: [embed] });
        } else {
          sentMessage = await targetChannel.send({ content });
        }
      }

      console.log(`✅ ${interaction.user.tag} sent a message in ${targetChannel.name}: ${content}`);

      const reply = await interaction.reply({ content: `✅ Message sent: [Jump to message](${sentMessage.url})`, ephemeral: true });

      setTimeout(async () => {
        try { await reply.delete(); } catch (e) {}
      }, 10000);

    } catch (error) {
      console.error(error);
      return interaction.reply({ content: `❌ An error occurred while sending the message.`, ephemeral: true });
    }
  },
};
