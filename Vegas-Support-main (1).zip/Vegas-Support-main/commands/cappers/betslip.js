const {
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionFlagsBits,
} = require('discord.js');
const Capper = require('../../schemas/Capper');
const Betslip = require('../../schemas/Betslip');
const Settings = require('../../schemas/Settings');

const convertAmericanToDecimal = (american) => {
  const odds = Number(american);
  if (odds > 0) return (odds / 100) + 1;
  if (odds < 0) return (100 / Math.abs(odds)) + 1;
  return null;
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('betslip')
    .setDescription('Create a new betslip (Capper only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages)
    .addAttachmentOption(option =>
      option.setName('image')
        .setDescription('Optional image attachment')
        .setRequired(false),
    ),

  async execute(interaction) {
    const userId = interaction.user.id;
    const isCapper = await Capper.findOne({ userId });
    if (!isCapper) {
      return interaction.reply({ content: '❌ You are not authorized to use this command.', ephemeral: true });
    }

    let selectedPlatform = null;
    let selectedSport = null;
    let selectedBetType = null;
    let uploadedImageUrl = interaction.options.getAttachment('image')?.url || null;

    const buildDescription = () => [
      '1️⃣ Upload your betslip image below (max 1)',
      `**Platform:** ${selectedPlatform || '_Not selected_'}`,
      `**Sport:** ${selectedSport || '_Not selected_'}`,
      `**Bet Type:** ${selectedBetType || '_Not selected_'}`,
      uploadedImageUrl ? '🖼️ Image uploaded and previewed.' : '_No image uploaded yet_',
      '',
      'Click **Send Message** when ready or **Cancel Bet** to abort.',
    ].join('\n');

    const embed = new EmbedBuilder()
      .setTitle('📋 Create a Betslip')
      .setDescription(buildDescription())
      .setColor('#7B3FBF')
      .setFooter({ text: 'Purple vibes only!' });
    if (uploadedImageUrl) embed.setImage(uploadedImageUrl);

    const platformSelect = new StringSelectMenuBuilder()
      .setCustomId('platform_select')
      .setPlaceholder('Select Platform')
      .addOptions(['Stake', 'Fanduel', 'Bet365', 'PrizePicks'].map(label => ({ label, value: label })));

    const sportSelect = new StringSelectMenuBuilder()
      .setCustomId('sport_select')
      .setPlaceholder('Select Sport')
      .addOptions(['Football', 'Basketball', 'Soccer', 'Hockey', 'Baseball', 'Tennis', 'MMA', 'Cricket', 'Rugby'].map(label => ({ label, value: label })));

    const betTypeSelect = new StringSelectMenuBuilder()
      .setCustomId('bet_type_select')
      .setPlaceholder('Select Bet Type')
      .addOptions(['Single', 'Parlay', 'Props', 'Same Game Parlay'].map(label => ({ label, value: label })));

    const sendButton = new ButtonBuilder().setCustomId('send_bet').setLabel('Send Message').setStyle(ButtonStyle.Primary);
    const cancelButton = new ButtonBuilder().setCustomId('cancel_bet').setLabel('Cancel Bet').setStyle(ButtonStyle.Danger);

    const rows = [
      new ActionRowBuilder().addComponents(platformSelect),
      new ActionRowBuilder().addComponents(sportSelect),
      new ActionRowBuilder().addComponents(betTypeSelect),
      new ActionRowBuilder().addComponents(cancelButton, sendButton),
    ];

    await interaction.reply({ embeds: [embed], components: rows, ephemeral: true });
    const message = await interaction.fetchReply();
    const channel = interaction.channel;

    const updateEmbed = async () => {
      const updatedEmbed = new EmbedBuilder()
        .setTitle('📋 Create a Betslip')
        .setDescription(buildDescription())
        .setColor('#7B3FBF')
        .setFooter({ text: 'Purple vibes only!' });
      if (uploadedImageUrl) updatedEmbed.setImage(uploadedImageUrl);
      await interaction.editReply({ embeds: [updatedEmbed] });
    };

    const filter = i => i.user.id === userId;
    const componentCollector = message.createMessageComponentCollector({ filter, time: 5 * 60 * 1000 });
    const attachmentCollector = channel.createMessageCollector({
      filter: m => m.author.id === userId && m.attachments.size > 0,
      max: 1,
      time: 5 * 60 * 1000,
    });

    attachmentCollector.on('collect', async msg => {
      const image = msg.attachments.find(att => att.contentType?.startsWith('image'));
      if (!image) {
        await interaction.followUp({ content: '❌ Please upload a valid image.', ephemeral: true });
        return;
      }
      uploadedImageUrl = image.url;
      await updateEmbed();
      try { await msg.delete(); } catch { }
    });

    componentCollector.on('collect', async i => {
      if (i.isStringSelectMenu()) {
        if (i.customId === 'platform_select') selectedPlatform = i.values[0];
        if (i.customId === 'sport_select') selectedSport = i.values[0];
        if (i.customId === 'bet_type_select') selectedBetType = i.values[0];
        await i.update({ components: rows });
        await updateEmbed();
      }

      if (i.isButton()) {
        if (i.customId === 'cancel_bet') {
          componentCollector.stop('cancelled');
          attachmentCollector.stop();
          await interaction.editReply({ content: '❌ Bet creation cancelled.', components: [], embeds: [] });
          return;
        }

        if (i.customId === 'send_bet') {
          if (!selectedPlatform) return i.reply({ content: '❌ Select a platform!', ephemeral: true });
          if (!selectedSport) return i.reply({ content: '❌ Select a sport!', ephemeral: true });
          if (!selectedBetType) return i.reply({ content: '❌ Select a bet type!', ephemeral: true });

          const modal = new ModalBuilder()
            .setCustomId('betslip_details_modal')
            .setTitle('Enter Betslip Details')
            .addComponents(
              ['Bet Title', 'Units', 'American Odds (e.g. +150 or -200)', 'Betslip Link', 'Description'].map((label, idx) =>
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId(['title', 'units', 'americanOdds', 'betslipLink', 'description'][idx])
                    .setLabel(label)
                    .setStyle(idx === 4 ? TextInputStyle.Paragraph : TextInputStyle.Short)
                    .setRequired(idx !== 3) // <--- 'betslipLink' at index 3 is NOT required
                )
              )
            );

          await i.showModal(modal);
          componentCollector.stop();
          attachmentCollector.stop();
        }
      }
    });

    try {
      const modalInteraction = await interaction.awaitModalSubmit({
        filter: i => i.user.id === userId && i.customId === 'betslip_details_modal',
        time: 2 * 60 * 1000,
      });

      const fields = ['title', 'units', 'americanOdds', 'betslipLink', 'description']
        .reduce((obj, key) => ({ ...obj, [key]: modalInteraction.fields.getTextInputValue(key).trim() }), {});

      const units = parseFloat(fields.units);
      const decimalOdds = convertAmericanToDecimal(fields.americanOdds);

      if (isNaN(units) || units <= 0) return modalInteraction.reply({ content: '❌ Units must be a positive number.', ephemeral: true });
      if (!/^[-+]?\d+$/.test(fields.americanOdds) || fields.americanOdds === '0' || !decimalOdds || decimalOdds <= 1) {
        return modalInteraction.reply({ content: '❌ Invalid American odds.', ephemeral: true });
      }
      const betslipLink = modalInteraction.fields.getTextInputValue('betslipLink').trim();
      const finalBetslipLink = (!betslipLink || !betslipLink.startsWith('http')) ? 'https://discord.gg/vegasplaymaker' : betslipLink;

      // Create preview embed
      const previewEmbed = new EmbedBuilder()
        .setAuthor({ name: fields.title })
        .setColor('#7B3FBF')
        .setDescription(fields.description)
        .addFields(
          { name: 'Units', value: units.toString(), inline: true },
          { name: 'Odds', value: fields.americanOdds, inline: true },
          { name: 'Platform', value: selectedPlatform, inline: true },
          { name: 'Sport', value: selectedSport, inline: true },
          { name: 'Bet Type', value: selectedBetType, inline: true },
        )
        .setFooter({ text: 'Please confirm to post this betslip.' });

      if (uploadedImageUrl) previewEmbed.setImage(uploadedImageUrl);


      const confirmButton = new ButtonBuilder()
        .setCustomId('confirm_betslip')
        .setLabel('✅ Confirm')
        .setStyle(ButtonStyle.Success);

      const cancelButton = new ButtonBuilder()
        .setCustomId('cancel_betslip')
        .setLabel('❌ Cancel')
        .setStyle(ButtonStyle.Danger);

      const actionRow = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

      await modalInteraction.reply({ embeds: [previewEmbed], components: [actionRow], ephemeral: true });

      const confirmation = await modalInteraction.channel.awaitMessageComponent({
        filter: i => i.user.id === userId && ['confirm_betslip', 'cancel_betslip'].includes(i.customId),
        time: 2 * 60 * 1000,
      });

      if (confirmation.customId === 'cancel_betslip') {
        await confirmation.update({ content: '❌ Bet creation cancelled.', components: [], embeds: [] });
        return;
      }

      if (confirmation.customId === 'confirm_betslip') {
        await confirmation.deferUpdate();

        const betEmbed = new EmbedBuilder()
          .setAuthor({ name: fields.title })
          .setColor('#7B3FBF')
          .setDescription(fields.description)
          .addFields({ name: 'Units', value: units.toString(), inline: true })
          .setTimestamp();

        if (uploadedImageUrl) betEmbed.setImage(uploadedImageUrl);


        const gradeButtons = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('win').setLabel('🟢 WIN').setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId('push').setLabel('⚪ PUSH').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('loss').setLabel('🔴 LOSS').setStyle(ButtonStyle.Danger),
        );

        const betMessage = await interaction.channel.send({ embeds: [betEmbed], components: [gradeButtons] });

        await Betslip.create({
          capperId: userId,
          messageId: betMessage.id,
          platform: selectedPlatform,
          sport: selectedSport,
          betType: selectedBetType,
          title: fields.title,
          units,
          americanOdds: fields.americanOdds,
          decimalOdds,
          betslipLink: finalBetslipLink,
          description: fields.description,
          imageUrl: uploadedImageUrl,
          createdAt: new Date(),
        });

        await modalInteraction.followUp({ content: '✅ Betslip posted successfully!', ephemeral: true });
        await interaction.editReply({ content: '✅ Betslip creation complete.', components: [], embeds: [] });

        // Optional: Send to logs channel
        const settings = await Settings.findOne({ guildId: interaction.guild.id });
        const logsChannel = settings && interaction.guild.channels.cache.get(settings.logsChannelId);

        let emoji = null;

        const platformEmojis = {
          Stake: '1377747916017369228',
          Fanduel: '1377748884461322392',
          Bet365: '1377748887191949413',
          PrizePicks: '1377747315229462690',
        };

        if (platformEmojis[selectedPlatform]) {
          emoji = platformEmojis[selectedPlatform];
        }

        if (logsChannel) {
          const betslipButton = new ButtonBuilder()
            .setLabel(`Place The Bet On ${selectedPlatform}`)
            .setStyle(ButtonStyle.Link)
            .setURL(finalBetslipLink)
            .setEmoji(emoji);

          const betslipButtonRow = new ActionRowBuilder().addComponents(betslipButton);

          await logsChannel.send({
            embeds: [betEmbed],
            components: [betslipButtonRow],
          });
        }
      }
    } catch {
      await interaction.editReply({ content: '⌛ Betslip creation timed out.', components: [], embeds: [] });
    }
  },
};