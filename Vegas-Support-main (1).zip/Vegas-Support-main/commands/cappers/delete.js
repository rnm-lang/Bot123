const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('delete')
    .setDescription('Delete a message in the target channel by Message ID.')
    .addStringOption(option =>
      option.setName('message_id')
        .setDescription('The message ID to delete')
        .setRequired(true)),

  async execute(interaction) {
    const allowedChannelId = '1375919939277422694'; // Command only here
    const targetChannelId = '1375919980503236680';  // Target channel for deletions
    const adminRoleId = '1375927086803587153';            // Replace with your Admin role ID

    // Restrict channel
    if (interaction.channel.id !== allowedChannelId) {
      return interaction.reply({ content: `❌ This command can only be used in <#${allowedChannelId}>.`, ephemeral: true });
    }

    // Restrict role
    if (!interaction.member.roles.cache.has(adminRoleId)) {
      return interaction.reply({ content: `❌ You don't have permission to use this command.`, ephemeral: true });
    }

    const messageId = interaction.options.getString('message_id');
    const targetChannel = await interaction.client.channels.fetch(targetChannelId);
    if (!targetChannel) {
      return interaction.reply({ content: `❌ Could not find the target channel.`, ephemeral: true });
    }

    try {
      const messageToDelete = await targetChannel.messages.fetch(messageId).catch(() => null);
      if (!messageToDelete) {
        return interaction.reply({ content: `❌ Could not find message with ID ${messageId} in <#${targetChannelId}>.`, ephemeral: true });
      }

      await messageToDelete.delete();
      console.log(`🗑️ ${interaction.user.tag} deleted a message in ${targetChannel.name}: ${messageId}`);

      const reply = await interaction.reply({ content: `✅ Message deleted: ${messageId}`, ephemeral: true });

      setTimeout(async () => {
        try { await reply.delete(); } catch (e) {}
      }, 10000);

    } catch (error) {
      console.error(error);
      return interaction.reply({ content: `❌ An error occurred while deleting the message.`, ephemeral: true });
    }
  },
};
