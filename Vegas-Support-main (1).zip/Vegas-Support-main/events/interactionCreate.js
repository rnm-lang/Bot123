const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const Betslip = require('../schemas/Betslip');
const Capper = require('../schemas/Capper');

module.exports = async (client, interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      // Execute slash command
      await command.execute(interaction);
    }

    else if (interaction.isButton()) {
      // Handle WIN, PUSH, LOSS buttons
      const betResults = {
        win: { label: 'WIN', color: 0x2ecc71, emoji: '🟢' },
        push: { label: 'PUSH', color: 0x95a5a6, emoji: '⚪' },
        loss: { label: 'LOSS', color: 0xe74c3c, emoji: '🔴' },
      };

      if (interaction.customId in betResults) {
        const betslip = await Betslip.findOne({ messageId: interaction.message.id });
        if (!betslip) {
          return interaction.reply({ content: '❌ Bet data not found.', ephemeral: true });
        }

        // Update result
        betslip.result = interaction.customId;
        await betslip.save();

        // Update embed color and footer
        const embed = interaction.message.embeds[0];
        if (!embed) {
          return interaction.reply({ content: '❌ Embed not found.', ephemeral: true });
        }
        const newEmbed = EmbedBuilder.from(embed)
          .setColor(betResults[interaction.customId].color)
          .setFooter({ text: `${betResults[interaction.customId].emoji} Result: ${betResults[interaction.customId].label}` });

        await interaction.update({ embeds: [newEmbed], components: [] });
      }
    }

    // Add modal submit handler here if you have modals that need handling

  } catch (error) {
    console.error('Interaction error:', error);
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: '❌ Something went wrong.', ephemeral: true });
    }
  }
};