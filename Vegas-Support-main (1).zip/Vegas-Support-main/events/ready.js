// ready.js
require('dotenv').config();
const { ChannelType, PermissionsBitField, Events, WebhookClient, EmbedBuilder } = require('discord.js');
const { joinVoiceChannel } = require('@discordjs/voice');

// Webhook client setup
const webhook = new WebhookClient({ url: 'https://discord.com/api/webhooks/1375910600713961582/CeC8ToS8wjLwf0sB1j3EdZAtYk0VfJOBWnKykgCsswTT_bEeccP0IVfR09gwC9nyFkqY' });

module.exports = async (client) => {
  console.log(`✅ Bot is online and initializing...`);

  // Webhook embed
  const embed = new EmbedBuilder()
    .setTitle('🎲 VegasPlaymaker Bot is now Online!')
    .setDescription('The **VegasPlaymaker** bot is ready to help you with betting insights, odds conversion, and more!')
    .addFields(
      { name: 'Bot Name', value: `${client.user.username}`, inline: true },
      { name: 'Bot ID', value: `${client.user.id}`, inline: true },
      { name: 'Version', value: 'v1.0.0', inline: true },
      { name: 'Status', value: '✅ Online and ready!', inline: true },
      { name: 'Ping', value: `${client.ws.ping} ms`, inline: true },
    )
    .setThumbnail(client.user.displayAvatarURL())
    .setFooter({ text: 'Brought to you by the VegasPlaymaker team.' })
    .setTimestamp()
    .setColor('#7B3FBF');

  try {
    await webhook.send({ embeds: [embed] });
    console.log('✅ Webhook embed sent successfully');
  } catch (error) {
    console.error('❌ Error sending webhook embed:', error);
  }

  // Join voice channel
  const channelId = '1375746187549999164';
  const channel = await client.channels.fetch(channelId);

  if (!channel || channel.type !== 2) {
    console.error('❌ Could not find the voice channel or it\'s not a voice channel');
  } else {
    try {
      joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
      });

      console.log(`✅ Joined voice channel: ${channel.name}`);
    } catch (error) {
      console.error('❌ Error joining voice channel:', error);
    }
  }
};
